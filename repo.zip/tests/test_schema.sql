-- Minimal schema for running Django tests with unmanaged Supabase tables

-- Items
CREATE TABLE IF NOT EXISTS items (
    item_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    base_unit VARCHAR(50),
    purchase_unit VARCHAR(50),
    category_id_ref INT,
    permitted_departments TEXT,
    reorder_point INT DEFAULT 0,
    reorder_qty INT DEFAULT 0,
    current_stock NUMERIC DEFAULT 0,
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Suppliers
CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255),
    phone VARCHAR(50),
    email VARCHAR(255),
    address TEXT,
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stock Transactions
CREATE TABLE IF NOT EXISTS stock_transactions (
    transaction_id SERIAL PRIMARY KEY,
    item_id INT REFERENCES items(item_id),
    qty NUMERIC NOT NULL,
    transaction_type VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recipes
CREATE TABLE IF NOT EXISTS recipes (
    recipe_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

-- Recipe Components
CREATE TABLE IF NOT EXISTS recipe_components (
    id SERIAL PRIMARY KEY,
    recipe_id INT REFERENCES recipes(recipe_id),
    component_kind VARCHAR(50), -- ITEM or RECIPE
    component_id INT,
    qty NUMERIC DEFAULT 0
);

-- Indents
CREATE TABLE IF NOT EXISTS indents (
    indent_id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'PENDING'
);

-- Purchase Orders
CREATE TABLE IF NOT EXISTS purchase_orders (
    po_id SERIAL PRIMARY KEY,
    supplier_id INT REFERENCES suppliers(supplier_id),
    status VARCHAR(50) DEFAULT 'OPEN',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Goods Receiving Notes
CREATE TABLE IF NOT EXISTS goods_receiving_notes (
    grn_id SERIAL PRIMARY KEY,
    po_id INT REFERENCES purchase_orders(po_id),
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
