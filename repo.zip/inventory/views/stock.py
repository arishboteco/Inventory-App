import csv
import io
from decimal import Decimal

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse

from ..forms.stock_forms import (
    StockAdjustmentForm,
    StockBulkUploadForm,
    StockReceivingForm,
    StockWastageForm,
)
from ..models import StockTransaction
from ..services import stock_service


def stock_movements(request):
    sections = {
        "receive": "Goods Received",
        "adjust": "Stock Adjustment",
        "waste": "Wastage/Spoilage",
    }
    active = request.GET.get("section", "receive")

    item_url = reverse("item_search")

    receive_form = StockReceivingForm(prefix="receive", item_suggest_url=item_url)
    adjust_form = StockAdjustmentForm(prefix="adjust", item_suggest_url=item_url)
    waste_form = StockWastageForm(prefix="waste", item_suggest_url=item_url)
    quick_form = StockAdjustmentForm(prefix="quick", item_suggest_url=item_url)
    bulk_form = StockBulkUploadForm()
    bulk_success_count = None
    bulk_errors: list[str] | None = None

    if request.method == "POST":
        if "submit_receive" in request.POST:
            receive_form = StockReceivingForm(
                request.POST, prefix="receive", item_suggest_url=item_url
            )
            if receive_form.is_valid():
                cd = receive_form.cleaned_data
                ok = stock_service.record_stock_transaction(
                    item_id=cd["item"].pk,
                    quantity_change=cd["quantity_change"],
                    transaction_type="RECEIVING",
                    user_id=cd.get("user_id"),
                    related_po_id=cd.get("related_po_id"),
                    notes=cd.get("notes"),
                )
                if ok:
                    messages.success(request, "Receiving transaction recorded")
                    return redirect("stock_movements")
                messages.error(request, "Failed to record transaction")
            active = "receive"
        elif "submit_adjust" in request.POST:
            adjust_form = StockAdjustmentForm(
                request.POST, prefix="adjust", item_suggest_url=item_url
            )
            if adjust_form.is_valid():
                cd = adjust_form.cleaned_data
                ok = stock_service.record_stock_transaction(
                    item_id=cd["item"].pk,
                    quantity_change=cd["quantity_change"],
                    transaction_type="ADJUSTMENT",
                    user_id=cd.get("user_id"),
                    notes=cd.get("notes"),
                )
                if ok:
                    messages.success(request, "Adjustment transaction recorded")
                    return redirect("stock_movements" + "?section=adjust")
                messages.error(request, "Failed to record transaction")
            active = "adjust"
        elif "submit_waste" in request.POST:
            waste_form = StockWastageForm(
                request.POST, prefix="waste", item_suggest_url=item_url
            )
            if waste_form.is_valid():
                cd = waste_form.cleaned_data
                qty = -abs(cd["quantity_change"])
                ok = stock_service.record_stock_transaction(
                    item_id=cd["item"].pk,
                    quantity_change=qty,
                    transaction_type="WASTAGE",
                    user_id=cd.get("user_id"),
                    notes=cd.get("notes"),
                )
                if ok:
                    messages.success(request, "Wastage transaction recorded")
                    return redirect("stock_movements" + "?section=waste")
                messages.error(request, "Failed to record transaction")
            active = "waste"
        elif "submit_quick" in request.POST:
            quick_form = StockAdjustmentForm(
                request.POST, prefix="quick", item_suggest_url=item_url
            )
            if quick_form.is_valid():
                cd = quick_form.cleaned_data
                ok = stock_service.record_stock_transaction(
                    item_id=cd["item"].pk,
                    quantity_change=cd["quantity_change"],
                    transaction_type="ADJUSTMENT",
                    user_id=cd.get("user_id"),
                    notes=cd.get("notes"),
                )
                if ok:
                    messages.success(request, "Quick movement recorded")
                    return redirect("stock_movements")
                messages.error(request, "Failed to record transaction")
            active = "receive"
        elif "bulk_upload" in request.POST:
            bulk_form = StockBulkUploadForm(request.POST, request.FILES)
            bulk_success_count = 0
            bulk_errors = []
            if bulk_form.is_valid():
                file = bulk_form.cleaned_data["file"]
                data = io.StringIO(file.read().decode("utf-8"))
                reader = csv.DictReader(data)
                txs_to_create = []
                for idx, row in enumerate(reader):
                    item_id_str = row.get("item_id", "").strip()
                    quantity_str = row.get("quantity_change", "").strip()

                    if not item_id_str or not quantity_str:
                        bulk_errors.append(
                            f"Row {idx+2}: Missing item_id or quantity_change"
                        )
                        continue

                    try:
                        item_id = int(item_id_str)
                        quantity = Decimal(quantity_str)

                        txs_to_create.append(
                            {
                                "item_id": item_id,
                                "quantity_change": quantity,
                                "transaction_type": row.get(
                                    "transaction_type", "ADJUSTMENT"
                                ).strip(),
                                "user_id": row.get("user_id", "System").strip(),
                                "user_int": (
                                    int(row.get("user_int"))
                                    if row.get("user_int")
                                    else None
                                ),
                                "related_indent_id": (
                                    int(row.get("related_indent_id"))
                                    if row.get("related_indent_id")
                                    else None
                                ),
                                "related_po_id": (
                                    int(row.get("related_po_id"))
                                    if row.get("related_po_id")
                                    else None
                                ),
                                "notes": row.get("notes"),
                            }
                        )
                    except (ValueError, TypeError):
                        bulk_errors.append(
                            f"Row {idx+2}: Invalid number format for item_id or quantity_change",
                        )

                if not bulk_errors and txs_to_create:
                    if stock_service.record_stock_transactions_bulk(txs_to_create):
                        bulk_success_count = len(txs_to_create)
                    else:
                        bulk_errors.append(
                            "A database error occurred during the bulk transaction."
                        )
                elif not txs_to_create and not bulk_errors:
                    bulk_errors.append("No valid rows found in the uploaded file.")

            active = request.GET.get("section", "receive")
    qs = StockTransaction.objects.select_related("item").order_by("-transaction_date")
    paginator = Paginator(qs, 25)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    for tx in page_obj:
        tx.direction = "in" if tx.quantity_change >= 0 else "out"

    params = request.GET.copy()
    params.pop("page", None)
    query_string = params.urlencode()

    tabs = [
        {
            "id": "receive",
            "title": sections["receive"],
            "template": "inventory/_receive_form.html",
        },
        {
            "id": "adjust",
            "title": sections["adjust"],
            "template": "inventory/_adjust_form.html",
        },
        {
            "id": "waste",
            "title": sections["waste"],
            "template": "inventory/_waste_form.html",
        },
    ]
    tabs.sort(key=lambda t: t["id"] != active)

    ctx = {
        "tabs": tabs,
        "receive_form": receive_form,
        "adjust_form": adjust_form,
        "waste_form": waste_form,
        "quick_form": quick_form,
        "bulk_form": bulk_form,
        "bulk_success_count": bulk_success_count,
        "bulk_errors": bulk_errors,
        "page_obj": page_obj,
        "query_string": query_string,
    }
    return render(request, "inventory/stock_movements.html", ctx)


def history_reports(request):
    item = (request.GET.get("item") or request.GET.get("q") or "").strip()
    tx_type = (request.GET.get("type") or "").strip()
    user = (request.GET.get("user") or "").strip()
    start_date = (request.GET.get("start_date") or "").strip()
    end_date = (request.GET.get("end_date") or "").strip()
    sort = (request.GET.get("sort") or "date").strip()
    direction = (request.GET.get("direction") or "desc").strip()

    qs = StockTransaction.objects.select_related("item").all()
    if item:
        qs = qs.filter(item_id=item)
    if tx_type:
        qs = qs.filter(transaction_type=tx_type)
    if user:
        qs = qs.filter(user_id=user)
    if start_date:
        qs = qs.filter(transaction_date__gte=start_date)
    if end_date:
        qs = qs.filter(transaction_date__lte=end_date)

    allowed_sorts = {
        "id": "transaction_id",
        "item": "item__name",
        "type": "transaction_type",
        "qty": "quantity_change",
        "user": "user_id",
        "date": "transaction_date",
    }
    if sort not in allowed_sorts:
        sort = "date"
    ordering = allowed_sorts[sort]
    ordering = ordering if direction != "desc" else f"-{ordering}"
    qs = qs.order_by(ordering)

    total_quantity = qs.aggregate(total=Sum("quantity_change"))["total"] or Decimal("0")

    if request.GET.get("export") == "csv":
        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = "attachment; filename=history_report.csv"
        writer = csv.writer(response)
        writer.writerow(
            [
                "Transaction ID",
                "Item",
                "Quantity",
                "Type",
                "User",
                "Date",
                "Notes",
            ]
        )
        for row in qs:
            writer.writerow(
                [
                    row.transaction_id,
                    getattr(row.item, "name", ""),
                    row.quantity_change,
                    row.transaction_type,
                    row.user_id,
                    row.transaction_date,
                    row.notes,
                ]
            )
        return response

    if request.GET.get("export") == "pdf":
        from fpdf import FPDF

        response = HttpResponse(content_type="application/pdf")
        response["Content-Disposition"] = "attachment; filename=history_report.pdf"

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", size=10)

        headers = [
            "Transaction ID",
            "Item",
            "Quantity",
            "Type",
            "User",
            "Date",
            "Notes",
        ]
        col_widths = [25, 30, 20, 25, 20, 30, 40]
        for head, width in zip(headers, col_widths):
            pdf.cell(width, 8, head, border=1)
        pdf.ln()

        for row in qs:
            pdf.cell(col_widths[0], 8, str(row.transaction_id), border=1)
            pdf.cell(col_widths[1], 8, getattr(row.item, "name", ""), border=1)
            pdf.cell(col_widths[2], 8, str(row.quantity_change), border=1)
            pdf.cell(col_widths[3], 8, row.transaction_type, border=1)
            pdf.cell(col_widths[4], 8, str(row.user_id), border=1)
            pdf.cell(
                col_widths[5],
                8,
                row.transaction_date.strftime("%Y-%m-%d"),
                border=1,
            )
            pdf.cell(col_widths[6], 8, (row.notes or "")[:40], border=1)
            pdf.ln()

        pdf_bytes = pdf.output(dest="S").encode("latin1")
        response.write(pdf_bytes)
        return response

    paginator = Paginator(qs, 25)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    transaction_types = (
        StockTransaction.objects.values_list("transaction_type", flat=True)
        .order_by("transaction_type")
        .distinct()
    )
    users = (
        StockTransaction.objects.exclude(user_id__isnull=True)
        .exclude(user_id="")
        .order_by("user_id")
        .values_list("user_id", flat=True)
        .distinct()
    )

    params = request.GET.copy()
    pagination_params = params.copy()
    pagination_params.pop("page", None)
    pagination_params.pop("export", None)
    query_string = pagination_params.urlencode()

    sort_params = pagination_params.copy()
    sort_params.pop("sort", None)
    sort_params.pop("direction", None)
    sort_query = sort_params.urlencode()

    filters = [
        {
            "name": "type",
            "value": tx_type,
            "list_id": "history-types",
            "options": [{"value": "", "label": "All Types"}]
            + [{"value": t} for t in transaction_types],
        },
        {
            "name": "user",
            "value": user,
            "list_id": "history-users",
            "options": [{"value": "", "label": "All Users"}]
            + [{"value": u} for u in users],
        },
    ]

    chart_qs = qs.order_by("transaction_date")
    chart_labels = [tx.transaction_date.strftime("%Y-%m-%d") for tx in chart_qs]
    chart_data = [float(tx.quantity_change) for tx in chart_qs]

    tabs = [
        {
            "id": "history-table-tab",
            "title": "Table",
            "template": "inventory/_history_table.html",
        },
        {
            "id": "history-chart-tab",
            "title": "Chart",
            "template": "inventory/_history_chart.html",
        },
    ]

    ctx = {
        "page_obj": page_obj,
        "transaction_types": transaction_types,
        "users": users,
        "item": item,
        "type": tx_type,
        "user": user,
        "start_date": start_date,
        "end_date": end_date,
        "query_string": query_string,
        "sort_query": sort_query,
        "sort": sort,
        "direction": direction,
        "total_quantity": total_quantity,
        "filters": filters,
        "chart_labels": chart_labels,
        "chart_data": chart_data,
        "tabs": tabs,
    }
    template = (
        "inventory/_history_tabs.html"
        if request.headers.get("HX-Request")
        else "inventory/history_reports.html"
    )
    return render(request, template, ctx)
